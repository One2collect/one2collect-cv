require('dotenv').config();
const express = require('express');
const multer = require('multer');
const nodemailer = require('nodemailer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const safeName = file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_');
    cb(null, `${Date.now()}-${safeName}`);
  }
});

const allowedMimeTypes = [
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
];

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (allowedMimeTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Alleen PDF, DOC en DOCX bestanden zijn toegestaan.'));
    }
  }
});

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT || 587),
  secure: String(process.env.SMTP_SECURE).toLowerCase() === 'true',
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  }
});

app.get('/health', (_req, res) => {
  res.json({ ok: true });
});

app.post('/upload-cv', upload.single('cv'), async (req, res) => {
  try {
    const { fullName, email, phone, message } = req.body;

    if (!fullName || !email || !req.file) {
      return res.status(400).send('Naam, e-mail en CV zijn verplicht.');
    }

    await transporter.sendMail({
      from: process.env.MAIL_FROM || process.env.SMTP_USER,
      to: process.env.RECEIVER_EMAIL,
      subject: `Nieuwe CV upload van ${fullName}`,
      text: [
        `Naam: ${fullName}`,
        `E-mail: ${email}`,
        `Telefoon: ${phone || '-'}`,
        `Bericht: ${message || '-'}`
      ].join('\n'),
      html: `
        <h2>Nieuwe CV upload</h2>
        <p><strong>Naam:</strong> ${fullName}</p>
        <p><strong>E-mail:</strong> ${email}</p>
        <p><strong>Telefoon:</strong> ${phone || '-'}</p>
        <p><strong>Bericht:</strong> ${message || '-'}</p>
      `,
      attachments: [
        {
          filename: req.file.originalname,
          path: req.file.path
        }
      ]
    });

    fs.unlink(req.file.path, () => {});
    res.sendFile(path.join(__dirname, 'public', 'success.html'));
  } catch (error) {
    console.error(error);
    res.status(500).send('Er ging iets mis bij het versturen van de CV.');
  }
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(400).send(err.message || 'Ongeldige upload.');
});

app.listen(PORT, () => {
  console.log(`Server draait op poort ${PORT}`);
});
